<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('css/summernote-bs4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <form id="contentEdit">
        <div class="row">
          <div class="col-sm-12">
            <div class="form-group">
              <label><?php echo e($model->key); ?></label>
              <input type="hidden" id="id" value="<?php echo e($model->id); ?>">
                <textarea id="content" class="form-control"><?php echo e($model->value); ?></textarea>
            </div>
          </div>
        </div>
        <button type="submit" id="save" class="btn btn-primary">Save</button>
        <a href="<?php echo e(route('content')); ?>"><button type="button" class="btn btn-default">Cancel</button></a>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script src="<?php echo e(asset('js/summernote-bs4.min.js')); ?>"></script>
  <script type="text/javascript">
    $('#content').summernote()

    $("#contentEdit").on('submit', function (e) {
      e.preventDefault();

      $("#save").attr('disabled', true);

      $.ajax({
        headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          url: '/update-content',
          data: {
            id: $("#id").val(),
            value: $("#content").val()
          },
          type: 'post',
      }).done(function(data) {
        data = JSON.parse(data);
        $("#save").attr('disabled', false);

        if (data.success) {
          showSuccess('Data updated successfully');
        } else {
          showError();
        }
      }).catch(function () {
        showError();
        $("#save").attr('disabled', false);
      });
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JupiterMeet\resources\views/admin/content-edit.blade.php ENDPATH**/ ?>