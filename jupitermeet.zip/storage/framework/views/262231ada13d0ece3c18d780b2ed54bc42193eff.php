<?php if(request()->session()->get('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(request()->session()->get('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="<?php echo e(__('Close')); ?>">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(request()->session()->get('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(request()->session()->get('error')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="<?php echo e(__('Close')); ?>">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\jupitermeet_cc\JupiterMeet_2.5.0\jupitermeet\resources\views/include/message.blade.php ENDPATH**/ ?>