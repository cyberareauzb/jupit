<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <table id="globalConfig" class="table table-bordered table-striped table-hover">
        <thead>
        <tr>
          <th>ID</th>
          <th>Key</th>
          <th>Value</th>
          <th>Description</th>
          <th>Action</th>
        </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($value->id); ?></td>
            <td><?php echo e($value->key); ?></td>
            <?php if($value->key == 'PRIMARY_COLOR' || $value->key == 'PRIMARY_COLOR_DISABLED' || $value->key == 'SECONDARY_COLOR'): ?>
              <td style="max-width: 250px">
                <div class="color-palette" style="background-color: <?php echo e($value->value); ?>">
                  <span><?php echo e($value->value); ?></span>
                </div>
              </td>
            <?php else: ?>
              <td style="max-width: 250px"><?php echo e($value->value); ?></td>
            <?php endif; ?>
            <td><?php echo e($value->description); ?></td>
            <td>
                <a href="/global-config/edit/<?php echo e($value->id); ?>">
                  <button class="btn btn-primary btn-sm">
                    <i class="fa fa-edit"></i>
                  </button>
                </a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr>
          <th>ID</th>
          <th>Key</th>
          <th>Value</th>
          <th>Description</th>
          <th>Action</th>
        </tr>
        </tfoot>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JupiterMeet\JupiterMeet_2.0.2\resources\views/admin/global-config/index.blade.php ENDPATH**/ ?>