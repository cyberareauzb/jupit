

<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('admin.coupons.new')); ?>" method="post" id="form-coupon">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label><?php echo e(__('Type')); ?></label>
                            <select name="type" id="i-type"
                                class="custom-select<?php echo e($errors->has('type') ? ' is-invalid' : ''); ?>">
                                <?php $__currentLoopData = [0 => __('Discount'), 1 => __('Redeemable')]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>" <?php if(old('type') == $key): ?> selected <?php endif; ?>>
                                        <?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('type')): ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($errors->first('type')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label><?php echo e(__('Name')); ?></label>
                            <input type="text" name="name" id="i-name"
                                class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('Name')); ?>">
                            <?php if($errors->has('name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="i-code"><?php echo e(__('Code')); ?></label>
                            <div class="input-group">
                                <input type="text" name="code" id="i-code"
                                    class="form-control<?php echo e($errors->has('code') ? ' is-invalid' : ''); ?>"
                                    value="<?php echo e(old('code')); ?>" placeholder="<?php echo e(__('Code')); ?>">
                                <div class="input-group-append">
                                    <div class="btn btn-primary" id="coupon_copy"><?php echo e(__('Copy')); ?></div>
                                </div>
                            </div>
                            <?php if($errors->has('code')): ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($errors->first('code')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-sm-6 <?php echo e(old('type') == 1 ? '' : 'd-none'); ?>" id="form-group-redeemable">
                        <div class="form-group">
                            <label for="i-days"><?php echo e(__('Days')); ?></label>
                            <input type="number" name="days" id="i-days"
                                class="form-control<?php echo e($errors->has('days') ? ' is-invalid' : ''); ?>"
                                value="<?php echo e(old('days') ?? 0); ?>" placeholder="<?php echo e(__('Days')); ?>">
                            <?php if($errors->has('days')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('days')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-6 <?php echo e((old('type') == 0 && old('type') !== null) || old('type') == null ? '' : 'd-none'); ?>"
                        id="form-group-discount">
                        <div class="form-group">
                            <label for="i-percentage"><?php echo e(__('Percentage off')); ?></label>
                            <div class="input-group">
                                <input type="text" name="percentage" id="i-percentage"
                                    class="form-control<?php echo e($errors->has('percentage') ? ' is-invalid' : ''); ?>"
                                    value="<?php echo e(old('percentage')); ?>"
                                    <?php echo e((old('type') == 0 && old('type') !== null) || old('type') == null ? '' : 'disabled'); ?>

                                    placeholder="<?php echo e(__('Percentage off')); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                            <?php if($errors->has('percentage')): ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($errors->first('percentage')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="i-quantity"><?php echo e(__('Quantity')); ?></label>
                            <input type="text" name="quantity" id="i-quantity"
                                class="form-control<?php echo e($errors->has('quantity') ? ' is-invalid' : ''); ?>"
                                value="<?php echo e(old('quantity')); ?>" placeholder="<?php echo e(__('Quantity')); ?>">
                            <?php if($errors->has('quantity')): ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($errors->first('quantity')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <button type="submit" id="save" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                <a href="<?php echo e(route('admin.coupons')); ?>"><button type="button"
                        class="btn btn-default"><?php echo e(__('Back')); ?></button></a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jupitermeet_cc\JupiterMeet_2.5.0\jupitermeet\resources\views/admin/coupons/new.blade.php ENDPATH**/ ?>